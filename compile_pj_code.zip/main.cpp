#include <iostream>
#include <string.h>
#include <stdio.h>
#include <iomanip>
#include "lexer.h"
#include <vector>
#include <map>

#define RED "\033[31m" 
#define RESET "\033[0m"
using namespace std;

int yylex();
extern "C" FILE* yyin;
extern "C" char* yytext;

int main(int argc, char** argv) {
    if (argc > 1) {
        FILE *file = fopen(argv[1], "r");
        if (!file) {
            cerr << "Cannot open file." << endl;
            return 1;
        } else {
            yyin = file;
        }
    } else {
        yyin = stdin;
    }
    
    // output header
    cout<<setw(5)<<left<<"Row"<<setw(5)<<left<<"Col"<<setw(20)<<left<<"Type"<<"Token/Error"<<endl;

    int token_num = 0;
    int error_num = 0;

    //caculate the index of rows and column
    int row = 1;
    int col = 1;
    map<pair<int,int>,vector<string>> errorinfo;
    while (true) {
        int n = yylex();
	int show = 1;
        string type = "";
        string token = "";
	
        if (n == T_EOF) break;
        switch(n) {
        case INTEGER:
                type = "integer";
                token = yytext;
		try{
			stoi(yytext);
		}
		catch(out_of_range& e){
			show = 0;
			token = "";
			type = "overflow error";
			errorinfo[{row,col}] = {type,yytext};
			error_num++;
			break;
		}
		catch(...){
		};
		token_num++;
                break;
        case REAL:
                type = "real";
                token = yytext;
		try{
			stoi(yytext);
		}
		catch(out_of_range& e){
			show = 0;
			token = "";
			type = "overflow error";
			errorinfo[{row,col}] = {type,yytext};
			error_num++;
			break;
		}
		catch(...){
		};
		token_num++;
            break;
            case BOOLEAN:
		type = "boolean";
		token = yytext;
		token_num++;
		break;
	    case WS:
		show = 0;
		token = yytext;
                type = "whitespace";
                break;
	    case RESERVED:
		type = "reserved";
		token = yytext;
                token_num++;
		break;
	    case ID:
		type = "ID";
		token = yytext;
		if(strlen(yytext)>255){
			show = 0;
			type = "overly long ID";
			token = "";
			errorinfo[{row,col}] = {type,yytext};
			error_num++;
			break;
		}
                token_num++;
		break;
            case STRING:
		type = "string";
		token = yytext;
		if(strlen(yytext)>257){
			show = 0;
			type = "overly long string";
			token = "";
			errorinfo[{row,col}] = {type,yytext};
			error_num++;
			break;
		}
		for(int i = 0; i < strlen(yytext); i++){
			if(yytext[i] == '\t'){
				show = 0;
				type = "tab in string";
				token = "";
				errorinfo[{row,col}] = {type,yytext};
				error_num++;
				break;
			}
		}
                token_num++;
		break;
             case OPERATOR:
		type = "operator";
		token = yytext;
                token_num++;
		break;
             case DELIMITER:
		type = "delimitor";
		token = yytext;
                token_num++;
		break;
	     case COMMENT:
		show = 0;
	        type = "comment";
		token = yytext;
		break;
	     case HALFCOMMENT:
		show = 0;
		type = "unterminated comment";
		errorinfo[{row,col}] = {type,yytext};
		error_num++;
		break;
            default:
		show = 0;
                type = "bad character";
		if(yytext[0] == '"')
			type = "unterminated string";
		errorinfo[{row,col}] = {type,yytext};
		error_num++;
        }
	if(show)
        	cout<<setw(5)<<left<<row<<setw(5)<<left<<col<<setw(20)<<left<<type<<token<<endl;
	
	//update rows and cols
	for(int i = 0; i < strlen(yytext); i++){
			if(yytext[i] == '\n'){
				row++;
				col = 1;
			}else if(yytext[i] == '\t'){
				col += 4;
			}
			else
				col++;
	}
	show = 1;
    }
    
    // count num of tokens and errors? 
    cout<<"tokens: "<<token_num<<" errors: "<<error_num<<endl;

    //print the errorinfos individually
    if(!errorinfo.empty()){
    	cout<<RED<<endl<<"Errors:"<<endl<<RESET;
    	for(auto &v:errorinfo)
		cout<<setw(5)<<left<<v.first.first<<setw(5)<<left<<v.first.second<<setw(20)<<left<<v.second[0]<<v.second[1]<<endl;
    }
    
    return 0;
}
