#ifndef _LEXER_H_
#define _LEXER_H_

#define T_EOF	  0 
#define INTEGER	  1
#define REAL	  2
#define BOOLEAN   3
#define WS	  4
#define RESERVED  5
#define ID        6
#define STRING    7
#define OPERATOR  8
#define DELIMITER 9
#define COMMENT   10
#define HALFCOMMENT 11
#define ERROR    -1
#endif
